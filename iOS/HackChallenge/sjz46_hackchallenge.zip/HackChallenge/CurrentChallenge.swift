//
//  CurrentChallenge.swift
//  HackChallenge
//
//  Created by Samantha Zhang on 5/3/21.
//

import UIKit

struct CurrentChallenge : Codable {
    var title: String
    var description: String
    var sender: String
}

